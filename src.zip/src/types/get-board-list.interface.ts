import Board from "./board.interface";

export default interface GetBoardList extends Board {
    createdAt: string;
}