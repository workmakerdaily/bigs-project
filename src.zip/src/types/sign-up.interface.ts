export default interface SignUp {
    username: string;
    name: string;
    password: string;
    confirmPassword: string;
}