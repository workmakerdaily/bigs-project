export default interface Board {
    id: number;
    title: string;
    category: string;
}