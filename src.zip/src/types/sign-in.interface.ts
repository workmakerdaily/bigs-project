export default interface SignIn {
    username: string;
    password: string;
}